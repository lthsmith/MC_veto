export DSHOWER_ENV=/home/lthsmith/Desktop/dShowerOL
export DSHOWER_WITH_OL=1
export OPENLOOPS=/home/lthsmith/Desktop/dShowerOL/OpenLoops
export LD_LIBRARY_PATH=$OPENLOOPS/lib:$LD_LIBRARY_PATH
