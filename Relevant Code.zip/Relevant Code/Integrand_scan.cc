#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <random>
#include <chrono>
#include <bits/stdc++.h>

#include "DGS.h"
#include "dShowerStdlib.h"
#include "mstwpdf.h"
#include "PDF.h"

using namespace dShower;

double integrand_PDGS(shared_ptr<DPDF> dpdf,double x1,double x2, double xbar1,double xbar2, double yr, double q,double flv1, double flv2, double flv3,double flv4){
	//function to pull integrand for pure DGS dPD, i.e. sqaure of no polarisation
	dpdf->setYParam(yr);
	
	double delta_1=dpdf->intrinsic(x1,xbar1,q,flv1,flv2,0,0);
	double delta_2=dpdf->intrinsic(x2,xbar2,q,flv3,flv4,0,0);
		
	return delta_1*delta_2;
}

double terms_mixpol(shared_ptr<DPDF> dpdf,double x1, double x2, double yr, double q, int flv1, int flv2,int n){
	//function to pull one term of integrand for mixed polarisation DGS, i.e. non polarised DGS dPD +/- aligned or anti-aligned dPD
	dpdf->setYParam(yr);
	
	double delta;
	
	if(n==0){
		delta=2.*dpdf->intrinsic(x1,x2,q,flv1,flv2,1,1);
	}else{
		delta=2.*dpdf->intrinsic(x1,x2,q,flv1,flv2,1,-1);
	}
	
	/*
	delta=dpdf->intrinsic(x1,x2,q,flv1,flv2,0,0)+1.*pow(-1,n)*(dpdf->intrinsic(x1,x2,q,flv1,flv2,1,1)-dpdf->intrinsic(x1,x2,q,flv1,flv2,-1,1));
	*/
	return delta;
}

double integrand_mixpol(shared_ptr<DPDF> dpdf,double x1, double x2, double x3, double x4, double yr, double q, int flv1, int flv2,int flv3,int flv4,int n){
	// function to 'square' terms to produce integrand
	
	double delta_1=terms_mixpol(dpdf,x1,x3,yr,q,flv1,flv2,n);
	
	double delta_2=terms_mixpol(dpdf,x2,x4,yr,q,flv3,flv4,n);
	
	return delta_1*delta_2;
}

double terms_MSTW(shared_ptr<SPDF> spdf,double x1,double x2,double yr, double q,int flv1, int flv2,double sigma_eff){
	//function to pull one term of integrand for the MSTW product ansatz, i.e. dPDF=sPDF*sPDF*f(y,effective cross-section)
	
	double delta_1=spdf->value(x1,q,flv1,false);
	double delta_2=spdf->value(x2,q,flv2,false);
	double gfn=exp(-1.*(yr-4.)*(yr-4.)/(2*sigma_eff*sigma_eff))*pow(sqrt(2*M_PI)*sigma_eff,-1);
	return delta_1*delta_2*gfn;
}

double integrand_MSTW(shared_ptr<SPDF> spdf,double x1, double x2, double x3, double x4, double yr, double q, int flv1, int flv2,int flv3,int flv4,double sigma_eff){
	//squares MSTW terms to produce itnegrand analogue
	double delta=terms_MSTW(spdf,x1,x3,yr,q,flv1,flv2,sigma_eff)*terms_MSTW(spdf,x2,x4,yr,q,flv3,flv4,sigma_eff);
	return delta;
}

vector<double> lim_finder_positive(double iters,double com_energy,double mass,double rapprod){
	/*
	Method to determine the high and low limits on Y1/Y2 that satisfy
	x1+x3 = e^Y1+e^Y2<q/Mw for a given Y1*Y2>0. x1+x3 has more stringent
	limits than x2+x4, which is trivially<q/Mw for all Y1/Y2.
	*/
	
	//set initial values for the low and high limits, the lowest 
	double frac_l=1.;
	double frac_h=1.;
	
	vector<double> lims; //vector to store limits
	lims.push_back(frac_l); //fill vector so if method fails there will still exist a value
	lims.push_back(frac_h);
	
	//Find low limit
	for(int i=0;i<iters;i++){
		
		//starting at 1, test whether frac_l breaks the condition
		double x1=(mass/com_energy)*exp(sqrt(rapprod*frac_l));
		//double x2=(mass/com_energy)*exp(-sqrt(rapprod*frac_l));
		double x3=(mass/com_energy)*exp(sqrt(rapprod/frac_l));
		//double x4=(mass/com_energy)*exp(-sqrt(rapprod/frac_l));
			
		
		if (x1+x3>1){
			//save first value that breaks condition, better to veto
			//than to miss some phase-space
			lims[0]=frac_l;
			//cout<<"low "<<i<<endl;
			break;
		}if(i==iters-1){
			lims[0]=frac_l;
		}
		//decrease frac_l towards zero until condition broken
		frac_l+=-1/iters;
	}
	
	//Find high limit
	for(int i=0;i<iters;i++){

		//starting at 1, test whether frac_h breaks the condition
		double x1=(mass/com_energy)*exp(sqrt(rapprod*frac_h));
		//double x2=(mass/com_energy)*exp(-sqrt(rapprod*frac_h));
		double x3=(mass/com_energy)*exp(sqrt(rapprod/frac_h));
		//double x4=(mass/com_energy)*exp(-sqrt(rapprod/frac_h));
		
		if (x1+x3>1){
			lims[1]=frac_h;//save first value that breaks condition
			//cout<<"high "<<i<<endl;
			break;
		}
		//increase frac_h until condition broken
		frac_h+=pow(log(com_energy/mass),2)/(rapprod*iters);
	}
	return lims;		
}

vector<double> lim_finder_negative(double iters,double com_energy,double mass,double rapprod){
	/*
	Method to determine the high and low limits on Y1/Y2 that satisfy
	x1+x4 = e^Y1+e^-Y2<q/Mw and x2+x3=e^-Y1+e^Y2<q/Mw for a given 
	Y1*Y2<0. here we must consider both x1+x4 and x2+x3 as they give
	the higher and lower limits respectively.
	*/
	
	//set initial values for the low and high limits, the lowest 
	double frac_l=-1.;
	double frac_h=-1.;
	
	vector<double> lims; //vector to store limits
	lims.push_back(frac_l); //fill vector so if method fails there will still exist a value
	lims.push_back(frac_h);
	
	//Find low limit
	for(int i=0;i<iters;i++){

		//starting at -1, test whether frac_l breaks the condition
		double x1 = (mass/com_energy)*exp(sqrt(rapprod*frac_l));
		//double x2 = (mass/com_energy)*exp(-sqrt(rapprod*frac_l));
		//double x3 = (mass/com_energy)*exp(sqrt(rapprod/frac_l));
		double x4 = (mass/com_energy)*exp(-sqrt(rapprod/frac_l));
		
		if (x1+x4>1){
			lims[0]=frac_l;//save first value that breaks condition
			//cout<<"low "<<i<<endl;
			break;
		}if(i==iters-1){
			lims[0]=frac_l;
		}
		//decrease frac_l until condition broken
		frac_l-=pow(log(com_energy/(2*mass)+sqrt(pow(com_energy/(2*mass),2)-1)),2)/(-rapprod*iters);
	}
	
	
	//Find high limit
	for(int i=0;i<iters;i++){
		
		//starting at -1, test whether frac_l breaks the condition
		//double x1 = (mass/com_energy)*exp(sqrt(rapprod*frac_h));
		double x2 = (mass/com_energy)*exp(-sqrt(rapprod*frac_h));
		double x3 = (mass/com_energy)*exp(sqrt(rapprod/frac_h));
		//double x4 = (mass/com_energy)*exp(-sqrt(rapprod/frac_h));
		
		if (x2+x3>1){
			//save first value that breaks condition, better to veto
			//than to miss some phase-space
			lims[1]=frac_h;
			//cout<<"high "<<i<<endl;
			break;
		}
		//increase frac_h towards zero until condition broken
		frac_h+=1/iters;	
	}
	
	return lims;		
}

double charge_dict(int flv){
	//charge dictionary to map quark labels from my internal notation used
	//in python script to determine relevant quark combos for W+W+/W-W- production
	//to notation in pDF script, which I should really just have used from beginning
	int flv_internal=flv+3;	
	vector<double> charges={1./3.,-2./3.,1./3.,0.,-1./3.,2./3.,-1./3.};
	return charges[flv_internal];
}

double val_finder(shared_ptr<DPDF> dpdf,shared_ptr<SPDF> spdf, double x1,double x2,double xbar1,double xbar2,int mix,int f1,int f2,int f3,int f4,double yr,double q,double com_energy,double Mw,double sigma_eff){
	
	double dpd_val;
	
	double raprat=log(com_energy*x1/Mw)/log(com_energy*x2/Mw);
	
	if(mix==0){
		dpd_val=2*yr*(1/(2.*raprat))*(integrand_PDGS(dpdf,x1,xbar1,x2,xbar2,yr,q,f1,f2,f3,f4)+integrand_PDGS(dpdf,xbar1,x1,xbar2,x2,yr,q,f1,f2,f3,f4));
		dpd_val+=2*yr*(1/(2.*raprat))*(integrand_PDGS(dpdf,x1,xbar1,x2,xbar2,yr,q,f1,f4,f3,f2)+integrand_PDGS(dpdf,xbar1,x1,xbar2,x2,yr,q,f1,f4,f3,f2));
	}else if(mix==1 or mix ==2){
		dpd_val=2*yr*(1/(2.*raprat))*(integrand_mixpol(dpdf,x1,xbar1,x2,xbar2,yr,q,f1,f2,f3,f4,0)+integrand_mixpol(dpdf,xbar1,x1,xbar2,x2,yr,q,f1,f2,f3,f4,0));
		dpd_val+=2*yr*(1/(2.*raprat))*(integrand_mixpol(dpdf,x1,xbar1,x2,xbar2,yr,q,f1,f4,f3,f2,1)+integrand_mixpol(dpdf,xbar1,x1,xbar2,x2,yr,q,f1,f4,f3,f2,1));
	}else if(mix==3){
		dpd_val=2*yr*(1/(2.*raprat))*(integrand_MSTW(spdf,x1,xbar1,x2,xbar2,yr,q,f1,f2,f3,f4,sigma_eff)+integrand_MSTW(spdf,xbar1,x1,xbar2,x2,yr,q,f1,f2,f3,f4,sigma_eff));
		dpd_val+=2*yr*(1/(2.*raprat))*(integrand_MSTW(spdf,x1,xbar1,x2,xbar2,yr,q,f1,f4,f3,f2,sigma_eff)+integrand_MSTW(spdf,xbar1,x1,xbar2,x2,yr,q,f1,f4,f3,f2,sigma_eff));
	}	
	
	return dpd_val;
}

int main(int argc, char *argv[]){	

	if (argc!=6){return -1;}
	//set mass of W boson
	double Mw=80.385;
	double sigma_eff;
	int sigtype=3;
	//set value of the effective cross-section for auxiliary f(y,sigma_eff)
	//in MSTW dPDF analogue
	if(sigtype==0){
		//valence option
		sigma_eff=1.62*sqrt(7.5*0.87)*20.;
	}else if(sigtype==1){
		//noval option
		sigma_eff=sqrt(380*17);
	}else if(sigtype==2){
		//nomom option
		sigma_eff=sqrt(330*17);
	}else if(sigtype==3){
		//noval and nomom option
		sigma_eff=sqrt(5100);
	}
	
	//select which dPDF to use, 0=PDGS, 1=Mixpol, 2=Pospol, 3=MSTW
	int mix=std::atoi(argv[1]);
	
	//take desired flavours 
	int f1=std::atoi(argv[2]);
	int f2=std::atoi(argv[3]);
	int f3=std::atoi(argv[4]);
	int f4=std::atoi(argv[5]);
	
	//Take hard scale equal to mass of W boson
	double q=Mw;
	
	//Set C.o.M energy to 14 TeV, 
	int com_energy=14000.;
	
	//assertations for kinematic & dShower limitations
	assert(com_energy > 2*Mw);
	assert(q<=172);
	
	//init. parameters for PDF initialisation
	ConstParam cstpar;
	Counter info;
	
	//set variety of important parameters
	cstpar.setRootS(com_energy);
	cstpar.setNFlv(3);
	cstpar.setMHatMax(172);
	cstpar.setUnequalScale(false);
	
	//declare varibles for s/dPDFs
	shared_ptr<DPDF> dpdf;
	shared_ptr<SPDF> spdf;
	//initialise s/dPDFs and set their parameters
	if(mix==0 or mix==1 or mix==2){
		dpdf.reset(new DGSLongPolDPDF(&cstpar,&info));
	}else if(mix==3){
		spdf.reset(new SMSTW2008(&cstpar,&info));
	}else{
		std::cout<<"Please select one of the given integral prescriptions"<<"\n";
		return -1;
	}
	
	//string to log whether this process describes W+W+ or W-W- production.
	std::string Wpos;
	double chsum=charge_dict(f1)+charge_dict(f2)+charge_dict(f3)+charge_dict(f4);
	if(chsum>0){
		Wpos = "W+";
	}else{
		Wpos = "W-";
	}
	
	ofstream file_scans;
	
	if(mix==0){
		std::string scanname = "/home/lthsmith/Desktop/dShowerOL/src/Integrals/scans/PDGS/Pure DGS_vals_"+Wpos+"_"+std::to_string(f1)+std::to_string(f2)+std::to_string(f3)+std::to_string(f4)+'_'+std::to_string(com_energy)+".txt";
		file_scans.open(scanname);
	}if(mix==1){
		std::string scanname = "/home/lthsmith/Desktop/dShowerOL/src/Integrals/scans/Mixpol/Mixpol_vals_"+Wpos+"_"+std::to_string(f1)+std::to_string(f2)+std::to_string(f3)+std::to_string(f4)+'_'+std::to_string(com_energy)+".txt";
		file_scans.open(scanname);
	}if(mix==2){
		std::string scanname = "/home/lthsmith/Desktop/dShowerOL/src/Integrals/scans/Pospol/Pospol_vals_"+Wpos+"_"+std::to_string(f1)+std::to_string(f2)+std::to_string(f3)+std::to_string(f4)+'_'+std::to_string(com_energy)+".txt";
		file_scans.open(scanname);
	}if(mix==3){
		std::string scanname = "/home/lthsmith/Desktop/dShowerOL/src/Integrals/scans/MSTW/MSTW_vals_"+Wpos+"_"+std::to_string(f1)+std::to_string(f2)+std::to_string(f3)+std::to_string(f4)+'_'+std::to_string(com_energy)+".txt";
		file_scans.open(scanname);
	}
	
	file_scans<<"x1,x2,value of DPD"<<"\n";
	
	double x1;//=0.7;
	double x2;//=0.4;
	double xbar1;//=pow(Mw/com_energy,2)*1/x1;
	double xbar2;//=pow(Mw/com_energy,2)*1/x2;
	double val;
	
	double yr=4.0;
	
	int points=100;
	
	for(int i=1;i<points;i++){
		x1=1.*i/points;
		xbar1=pow(Mw/com_energy,2)*1/x1;
		for(int j=1;j<points;j++){
			x2=1.*j/points;
			xbar2=pow(Mw/com_energy,2)*1/x2;
			
			val=val_finder(dpdf,spdf, x1, x2, xbar1, xbar2, mix, f1, f2, f3, f4, yr, q, com_energy, Mw, sigma_eff);
			file_scans<<x1<<","<<x2<<","<<val<<"\n";
			//std::cout<<"Completed i: "<<i<<", j: "<<j<<"\n";
		}
	}
	
    //double val=val_finder(dpdf,spdf, x1, x2, xbar1, xbar2, mix, f1, f2, f3, f4, yr, q, com_energy, Mw, sigma_eff);
    
    file_scans.close();
    
	return 0;
}
