////////////////////////////////////////////////////////////////////////
// PDF.cc is part of the dShower simulation.
// Contacts:
// - B. Cabouat: baptiste.cabouat@gmail.com
//
// This code implements the PDF and dPDF sets which are used in the
// dShower simulation. For the dPDF sets satisfying the DGS framework,
// the valence and sea components are defined following the scheme given
// in [1906.04669].
// An interface with the ChiliPDF library is available.
////////////////////////////////////////////////////////////////////////

#include "PDF.h"

namespace dShower {
    
    // Some parameters.
    // Minimum value for the PDFs.
    const double SPDF::PDFMIN = 0.;
    const double DPDF::PDFMIN = 0.;
    // Maximum negative value.
    const double SPDF::MAXNEG = -10.;
    const double DPDF::MAXNEG = -10.;
    // Overestimating factors for PDF ratios.
    // MSTW2008.
    const double SMSTW2008::FACTG2G = 1.;
    const double SMSTW2008::FACTQ2G = 1.;
    const double SMSTW2008::FACTQ2Q = 1.;
    const double SMSTW2008::FACTG2Q = 1.;
    const double SMSTW2008::FACTG2QMASS = 1.;
    #ifdef DSHOWER_WITH_CHILIPDF
    // ChiliSPDF.
    const double ChiliSPDF::FACTG2G = 1.;
    const double ChiliSPDF::FACTQ2G = 1.;
    const double ChiliSPDF::FACTQ2Q = 1.;
    const double ChiliSPDF::FACTG2Q = 1.;
    const double ChiliSPDF::FACTG2QMASS = 1.;
    // ChiliDPDF.
    const double ChiliDPDF::FACTG2G = 1.;
    const double ChiliDPDF::FACTQ2G = 1.;
    const double ChiliDPDF::FACTQ2Q = 1.;
    const double ChiliDPDF::FACTG2Q = 1.;
    const double ChiliDPDF::FACTG2QMASS = 1.;
    #endif
    // DGSDPDF.
    const double DGSDPDF::FACTG2G = 1.;
    const double DGSDPDF::FACTQ2G = 1.;
    const double DGSDPDF::FACTQ2Q = 1.;
    const double DGSDPDF::FACTG2Q = 1.;
    const double DGSDPDF::FACTG2QMASS = 1.;
    // ProtoDGSDPDF.
    const double ProtoDGSDPDF::FACTG2G = 1.;
    const double ProtoDGSDPDF::FACTQ2G = 1.;
    const double ProtoDGSDPDF::FACTQ2Q = 1.;
    const double ProtoDGSDPDF::FACTG2Q = 1.;
    const double ProtoDGSDPDF::FACTG2QMASS = 1.;
    // Overestimating factors for hard boson ME corrections.
    // MSTW2008.
    const double SMSTW2008::FACTQ = 10.;
    const double SMSTW2008::FACTG = 10.;
    #ifdef DSHOWER_WITH_CHILIPDF
    // ChiliSPDF.
    const double ChiliSPDF::FACTQ = 10.;
    const double ChiliSPDF::FACTG = 10.;
    // ChiliDPDF.
    const double ChiliDPDF::FACTQ = 5.;
    const double ChiliDPDF::FACTG = 5.;
    #endif
    // DGSDPDF.
    const double DGSDPDF::FACTQ = 5.;
    const double DGSDPDF::FACTG = 5.;
    // ProtoDGSDPDF.
    const double ProtoDGSDPDF::FACTQ = 5.;
    const double ProtoDGSDPDF::FACTG = 5.;

///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Check input values.
    bool DPDF::checkInput(double x1, double x2, double q, int flv1, int flv2) {
        if (q <= 0. || q > qMax) return false;
        if (x1 < XMIN || x1 > 1.) return false;
        if (x2 < XMIN || x2 > 1.) return false;
        if (x1 + x2 > 1.) return false;
        if (!isAllowedFlv(flv1) || !isAllowedFlv(flv2)) return false;
        return true;
    }
    
    bool SPDF::checkInput(double x, double q, int flv) {
        if (q <= 0. || q > qMax) return false;
        if (x < XMIN || x > 1.) return false;
        if (!isAllowedFlv(flv)) return false;
        return true;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Return the dpdf value. The returned value is the dpdf only, and not x1 * x2 * dpdf.
    // In the case of a y-dependent set, it is the sum of the intrinsic and splitting parts.
    double DPDF::value(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        const double val = rawValue(x1,x2,q,flv1,flv2,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
    // Same as the function value but with sea and valence contributions separated.
    // In the case of a y-dependent set, it is the sum of the intrinsic and splitting parts.
    double DPDF::valuevs(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        const double val = intSplvs(x1,x2,q,flv1,flv2,false,pol1,pol2) + intSplvs(x1,x2,q,flv1,flv2,true,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
    // Return the pdf value. The returned value is the pdf only, and not x * pdf.
    double SPDF::value(double x, double q, int flv, int pol) {
        if (!checkInput(x,q,flv)) return PDFMIN;
        const double val = rawValue(x,q,flv,pol);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x,q,flv,pol);
            return PDFMIN;
        }
    }
    
    // Same as the function value but with sea and valence contributions separated.
    double SPDF::valuevs(double x, double q, int flv, int pol) {
        if (!checkInput(x,q,flv)) return PDFMIN;
        // 1 and 2 refer systematically to sea d and u quarks.
        // For valence, use 7 and 8.
        // Note that the returned value is the pdf only here,
        // and not x * pdf.
        if (flv == 1 || flv == 2) return value(x,q,-flv,pol);
        else return value(x,q,flv,pol);
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Intrinsic part.
    double DPDF::intrinsic(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        const double val = rawIntSpl(x1,x2,q,flv1,flv2,false,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
    // Splitting part.
    double DPDF::splitting(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        const double val = rawIntSpl(x1,x2,q,flv1,flv2,true,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
    // Intrinsic part, but with valence and sea contributions separated.
    double DPDF::intrinsicvs(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        const double val = intSplvs(x1,x2,q,flv1,flv2,false,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
    // Splitting part, but with valence and sea contributions separated.
    double DPDF::splittingvs(double x1, double x2, double q, int flv1, int flv2, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        const double val = intSplvs(x1,x2,q,flv1,flv2,true,pol1,pol2);
        if (val >= PDFMIN) return val;
        else {
            if (val < MAXNEG) info->newNegPDF(val);
            //printArg(val,x1,x2,q,flv1,flv2,pol1,pol2);
            return PDFMIN;
        }
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Constructor for SMSTW2008.
    SMSTW2008::SMSTW2008(ConstParam* cstParIn, Counter* infoIn):SPDF(cstParIn,infoIn) {
        // Check that DSHOWER_ENV has been set so dShower can find grids.
        if (!getenv("DSHOWER_ENV")) {
            cerr << "\e[1m\e[31;5;31mError:\e[0m Environment variable DSHOWER_ENV not set. Please set it equal to dShower installation directory" << endl;
            exit(-1);
        }
        // Select the PDF set corresponding to the number of active flavours.
        string pdfName;
        const int nFlv = cstPar->getNFlv();
        if (nFlv == 3) pdfName = "mstw2008lo";
        else if (nFlv == 5) pdfName = "mstw2008lo";
        else {
            cerr << "Error in PDF.cc (SMSTW2008::SMSTW2008): nFlv = 4 not implemented yet.\n";
            exit(-1);
        }
        string gridName(getenv("DSHOWER_ENV") + string("/share/SPDF/") + pdfName + string(".00.dat"));
        unique_ptr<c_mstwpdf> pdfIn(new c_mstwpdf(gridName));
        pdf = move(pdfIn);
        assert(pdf);
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    double DMSTW2008::intSplvs(double x1, double x2, double q, int flv1, int flv2, bool spl, int, int) {
        if (spl) return 0.;
        if (!checkInput(x1,x2,q,flv1,flv2)) return PDFMIN;
        if (!unequalScale) equalScaleMode = true;
        const double val = (!equalScaleMode) ? pdf->valuevs(x1,q,flv1) * pdf->valuevs(x2,qBis,flv2) : pdf->valuevs(x1,q,flv1) * pdf->valuevs(x2,q,flv2);
        if (val >= PDFMIN) return val;
        else return PDFMIN;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    GS09::GS09(ConstParam* cstParIn, Counter* infoIn):DPDF(cstParIn,infoIn) {
        const int nFlv = cstPar->getNFlv();
        if (nFlv == 4) {
            cerr << "Error in PDF.cc (GS09::GS09): nFlv = 4 not implemented yet.\n";
            exit(-1);
        }
    }
    
    double GS09::gs09value(double X1, double X2, double Q, int F1, int F2) {
        double val;
        gs09_(&X1, &X2, &Q, &F1, &F2, &val);
        return val;
    }
    
    double GS09::intSplvs(double, double, double, int, int, bool, int, int) {
        cerr << "Error in PDF.cc (GS09::intSplvs): valence/sea components not defined for GS09 set.\n";
        exit(-1);
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Constructor: initialise dPDFs.
    DGSDPDF::DGSDPDF(ConstParam* cstParIn, Counter* infoIn):DPDF(cstParIn,infoIn) {
        // Select the PDF set corresponding to the number of active flavours.
        string intName, splName;
        const int nFlv = cstPar->getNFlv();
        if (nFlv == 3) {
            intName = "intrinsic_3flv";
            splName = "splitting_3flv";
        } else if (nFlv == 5) {
            intName = "intrinsic_5flv";
            splName = "splitting_5flv";
        } else {
            cerr << "Error in PDF.cc (DGSDPDF::DGSDPDF): nFlv = 4 not implemented yet.\n";
            exit(-1);
        }
        unique_ptr<DGS> dpdfIn(new DGS(intName,splName,cstPar->getNFlv()));
        dpdf = move(dpdfIn);
        assert(dpdf);
        checkGridParam();
    }
    
    // Check that some parameters are consistent with the grid ones.
    void DGSDPDF::checkGridParam() {
        if (!(XMIN - dpdf->getXMin() > -1.e-12)) {
            cout << "Error in PDF.cc (DGSDPDF::checkGridParam): value of XMIN not consistent with DGS grid.\n";
            exit(-1);
        }
        if (!(dpdf->getQMax() - qMax > -1.e-6)) {
            cout << "Error in PDF.cc (DGSDPDF::checkGridParam): value of QMAX not consistent with DGS grid.\n";
            exit(-1);
        }
        return;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Constructor: initialise dPDFs.
    DGSLongPolDPDF::DGSLongPolDPDF(ConstParam* cstParIn, Counter* infoIn):DGSDPDF() {
        // Initialise values.
        cstPar = cstParIn;
        assert(cstPar);
        info = infoIn;
        assert(info);
        XMIN = cstPar->getXMin();
        YCUT = cstPar->getYCut();
        qMax = cstPar->getMHatMax();
        unequalScale = cstPar->getUnequalScale();
        // Select the PDF set corresponding to the number of active flavours.
        string intName, splName, intPolName, splPolName;
        const int nFlv = cstPar->getNFlv();
        if (nFlv == 3) {
            // (aligned,misaligned) grid.
            //intName = "intrinsic_3flv_align";
            //splName = "splitting_3flv_align";
            //intPolName = "intrinsic_3flv_misalign";
            //splPolName = "splitting_3flv_misalign";
            // (unpolarised,polarised) grid.
            
            bool valtype=false; //if true, use val, if false, use noval
            bool poltype=true; //if true, use mixpol, else use pospol
            int momtype=1; //if 0, use mom, if 1 use nomom, if 2 use really nomom
            
            //select whether to include momentum function 0=include,1=exclude
            if(momtype==0){
				//select whether to include valence contributions 0=include, 1=exclude
				if(valtype){
					intName = "intrinsic_3flv";
					std::cout<<"Momentum Valence ";
				}else{
					intName = "intrinsic_3flv_noval";
					std::cout<<"Momentum No-Valence ";
				}
				
				//select whether mixpol or pospol prescription 0=mixpol, 1=pospol
				if(poltype){
					intPolName = "intrinsic_3flv_Lpol";
					std::cout<<"MixPol dPDF set"<<"\n";
				}else{
					intPolName = "intrinsic_3flv_Lpol_pos";
					std::cout<<"Pospol dPDF set"<<"\n";
				}
			}else if(momtype==1){
				//select whether to include valence contributions
				if(valtype){
					intName = "intrinsic_3flv_nomom";
					std::cout<<"No-Momentum Valence ";
				}else{
					intName = "intrinsic_3flv_nomom_noval";
					std::cout<<"No-Momentum No-Valence ";
				}
				
				//select whether mixpol or pospol prescription
				if(poltype){
					intPolName = "intrinsic_3flv_Lpol_nomom";
					std::cout<<"MixPol dPDF set"<<"\n";
				}else{
					intPolName = "intrinsic_3flv_Lpol_nomom_pos";
					std::cout<<"Pospol dPDF set"<<"\n";
				}
			}else if(momtype==2){
				//select whether to include valence contributions
				if(valtype){
					intName = "intrinsic_3flv_really_nomom";
					std::cout<<"Really No-Momentum Valence ";
				}else{
					intName = "intrinsic_3flv_really_nomom_noval";
					std::cout<<"Really No-Momentum No-Valence ";
				}
				
				//select whether mixpol or pospol prescription
				if(poltype){
					intPolName = "intrinsic_3flv_Lpol_really_nomom";
					std::cout<<"MixPol dPDF set"<<"\n";
				}else{
					intPolName = "intrinsic_3flv_Lpol_really_nomom_pos";
					std::cout<<"Pospol dPDF set"<<"\n";
				}
			}
            splName = "splitting_3flv";
            splPolName = "splitting_3flv_Lpol";
        } else {
            cerr << "Error in PDF.cc (DGSLongPolDPDF::DGSLongPolDPDF): nFlv = 4 and nFlv = 5 not implemented yet.\n";
            exit(-1);
        }
        unique_ptr<DGSLongPol> dpdfIn(new DGSLongPol(intName,splName,intPolName,splPolName,cstPar->getNFlv()));
        dpdf = move(dpdfIn);
        assert(dpdf);
        checkGridParam();
    }
    
    // Raw intrinsic and splitting parts.
    double DGSLongPolDPDF::rawIntSpl(double x1, double x2, double q, int flv1, int flv2, bool spl, int pol1, int pol2) {
        // (aligned,misaligned) grid.
        //if (pol1 == 0 && pol2 == 0) return dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,false) + dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,true);
        // (unpolarised,polarised) grid.
        if (pol1 == 0 && pol2 == 0) return dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,false);
        const int prodPol = pol1 * pol2;
        assert(prodPol != 0);
        // (aligned,misaligned) grid.
        //if (prodPol > 0) return dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,false);
        //else return dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,true);
        // (unpolarised,polarised) grid.
        if (prodPol > 0) return 0.5 * (dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,false) + dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,true));
        else return 0.5 * (dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,false) - dpdf->value(x1,x2,ySaved,q,flv1,flv2,spl,true));
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    #ifdef DSHOWER_WITH_CHILIPDF
    chilipdf::Flavor ChiliSPDF::mapFlv(int flv) {
        assert(isAllowedFlv(flv));
        if (flv == 0) return chilipdf::Flavor::g;
        else if (flv == 1) return chilipdf::Flavor::d;
        else if (flv == -1) return chilipdf::Flavor::dbar;
        else if (flv == 2) return chilipdf::Flavor::u;
        else if (flv == -2) return chilipdf::Flavor::ubar;
        else if (flv == 3) return chilipdf::Flavor::s;
        else if (flv == -3) return chilipdf::Flavor::sbar;
        else if (flv == 4) return chilipdf::Flavor::c;
        else if (flv == -4) return chilipdf::Flavor::cbar;
        else if (flv == 5) return chilipdf::Flavor::b;
        else if (flv == -5) return chilipdf::Flavor::bbar;
        else if (flv == 7) return chilipdf::Flavor::d_minus;
        else if (flv == 8) return chilipdf::Flavor::u_minus;
        else {
            cout << "Error in PDF.cc (ChiliSPDF::mapFlv): wrong flavour.\n";
            exit(-1);
        }
    }
        
    chilipdf::Flavor ChiliDPDF::mapFlv(int flv) {
        assert(isAllowedFlv(flv));
        if (flv == 0) return chilipdf::Flavor::g;
        else if (flv == 1) return chilipdf::Flavor::d;
        else if (flv == -1) return chilipdf::Flavor::dbar;
        else if (flv == 2) return chilipdf::Flavor::u;
        else if (flv == -2) return chilipdf::Flavor::ubar;
        else if (flv == 3) return chilipdf::Flavor::s;
        else if (flv == -3) return chilipdf::Flavor::sbar;
        else if (flv == 4) return chilipdf::Flavor::c;
        else if (flv == -4) return chilipdf::Flavor::cbar;
        else if (flv == 5) return chilipdf::Flavor::b;
        else if (flv == -5) return chilipdf::Flavor::bbar;
        else {
            cout << "Error in PDF.cc (ChiliDPDF::mapFlv): wrong flavour.\n";
            exit(-1);
        }
    }
    
    double ChiliDPDF::rawIntSpl(double x1, double x2, double q, int flv1, int flv2, bool spl, int, int) {
        if (!unequalScale) equalScaleMode = true;
        chilipdf::Flavor f1 = mapFlv(flv1);
        chilipdf::Flavor f2 = mapFlv(flv2);
        double val = 0.;
        if (spl) {
            val = (!equalScaleMode) ? splPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,qBis}) : splPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,q});
        } else {
            val = (!equalScaleMode) ? intPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,qBis}) : intPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,q});
        }
        return val / (x1 * x2);
    }
    
    double ChiliDPDF::rawValue(double x1, double x2, double q, int flv1, int flv2, int, int) {
        if (!unequalScale) equalScaleMode = true;
        chilipdf::Flavor f1 = mapFlv(flv1);
        chilipdf::Flavor f2 = mapFlv(flv2);
        double val = (!equalScaleMode) ? sumPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,qBis}) : sumPtr->x1x2F({nFlv,nFlv},{f1,f2},x1,x2,ySaved,{q,q});
        return val / (x1 * x2);
    }
    #endif
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Constructor.
    ProtoDGSDPDF::ProtoDGSDPDF(ConstParam* cstParIn, Counter* infoIn, StandardModel* smIn):DPDF(cstParIn,infoIn) {
        unique_ptr<ProtoDGS> dpdfIn(new ProtoDGS(cstParIn,infoIn,smIn));
        dpdf = move(dpdfIn);
        assert(dpdf);
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Value of the dPDF, but with valence and sea contributions separated.
    // Note: 1 and 2 refer systematically to sea quarks. For valence d and u, use 7 and 8.
    double DPDF::intSplvs(double x1, double x2, double q, int f1, int f2, bool spl, int pol1, int pol2) {
        if (!checkInput(x1,x2,q,f1,f2)) return PDFMIN;
        // Use the symmetry properties in order to deal with the case abs(f1) >= abs(f2) only.
        const int absf1 = abs(f1);
        const int absf2 = abs(f2);
        if (absf1 < absf2) return DPDF::intSplvs(x2,x1,q,f2,f1,spl,pol2,pol1);
        // Now abs(f1) >= abs(f2).
        assert(absf1 >= absf2);
        // Start with contributions involving valence quarks.
        if (f1 > 6) {
            assert(f1 == 7 || f1 == 8);
            const int f1in = f1 - 6;
            assert(f1in == 1 || f1in == 2);
            if (f1 - absf2 == 6) {
                // Valence - sea terms: u_v,u_s; u_v,ubar; d_v,d_s and d_v,dbar.
                if (!spl) return rawIntSpl(x1,x2,q,f1in,-f1in,false,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,-f1in,false,pol1,pol2);
                else return 0.5 * (rawIntSpl(x1,x2,q,f1in,-f1in,true,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,f1in,true,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,-f1in,true,pol1,pol2) + rawIntSpl(x1,x2,q,f1in,f1in,true,pol1,pol2));
            } else if (f1 == f2) {
                // Valence - valence terms: u_v,u_v and d_v,d_v.
                if (!spl) return rawIntSpl(x1,x2,q,f1in,f1in,false,pol1,pol2) - rawIntSpl(x1,x2,q,f1in,-f1in,false,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,f1in,false,pol1,pol2) + rawIntSpl(x1,x2,q,-f1in,-f1in,false,pol1,pol2);
                else return 0.;
            } else if (f2 == 7) {
                // u_v,d_v term.
                assert(f1 == 8);
                if (!spl) return rawIntSpl(x1,x2,q,2,1,false,pol1,pol2) - rawIntSpl(x1,x2,q,-2,1,false,pol1,pol2) - rawIntSpl(x1,x2,q,2,-1,false,pol1,pol2) + rawIntSpl(x1,x2,q,-2,-1,false,pol1,pol2);
                else return 0.;
            } else if (f2 <= 0 || f2 >= 3) {
                // qs = s, c, b.
                // u_v,qs; u_v,dbar; u_v,qsbar; u_v,g; d_v,qs; d_v,ubar; d_v,qsbar and d_v,g.
                return rawIntSpl(x1,x2,q,f1in,f2,spl,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,f2,spl,pol1,pol2);
            } else {
                // u_v,d_s and d_v,u_s terms.
                assert(f2 == 1 || f2 == 2);
                if (!spl) return rawIntSpl(x1,x2,q,f1in,-f2,false,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,-f2,false,pol1,pol2);
                else return 0.5 * (rawIntSpl(x1,x2,q,f1in,-f2,true,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,f2,true,pol1,pol2) - rawIntSpl(x1,x2,q,-f1in,-f2,true,pol1,pol2) + rawIntSpl(x1,x2,q,f1in,f2,true,pol1,pol2));
            }
        } else if (absf1 >= 3) {
            // The first parton is qs or qsbar, with qs = s, c, b.
            // If the second parton is qs or qsbar too.
            if (absf2 >= 3) return rawIntSpl(x1,x2,q,f1,f2,spl,pol1,pol2);
            else {
                // The second parton is u_s, d_s, g, dbar or ubar.
                return rawIntSpl(x1,x2,q,f1,-absf2,spl,pol1,pol2);
            }
        } else if (absf1 == 2) {
            // The first parton is u_s or ubar.
            assert(absf2 <= 2);
            // Special terms u_s,ubar and ubar,u_s for the splitting part.
            if (f1 == -f2 && spl) return 0.5 * (rawIntSpl(x1,x2,q,2,-2,true,pol1,pol2) + rawIntSpl(x1,x2,q,-2,2,true,pol1,pol2) + rawIntSpl(x1,x2,q,-2,-2,true,pol1,pol2) - rawIntSpl(x1,x2,q,2,2,true,pol1,pol2));
            else return rawIntSpl(x1,x2,q,-2,-absf2,spl,pol1,pol2);
        } else if (absf1 == 1) {
            // The first parton is d_s or dbar.
            assert(absf2 <= 1);
            // Special terms d_s,dbar and dbar,d_s for the splitting part.
            if (f1 == -f2 && spl) return 0.5 * (rawIntSpl(x1,x2,q,1,-1,true,pol1,pol2) + rawIntSpl(x1,x2,q,-1,1,true,pol1,pol2) + rawIntSpl(x1,x2,q,-1,-1,true,pol1,pol2) - rawIntSpl(x1,x2,q,1,1,true,pol1,pol2));
            else return rawIntSpl(x1,x2,q,-1,-absf2,spl,pol1,pol2);
        } else if (f1 == 0) {
            // g,g term.
            assert(f2 == 0);
            return rawIntSpl(x1,x2,q,0,0,spl,pol1,pol2);
        } else {
            cout << "Error in PDF.cc (DPDF::intSplvs): wrong flavour combination.\n";
            exit(-1);
        }
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // Test evaluation time for dPDF values.
    void DPDF::testEvalTime(int nQ, int nY) {
        const double y_b = cstPar->getYCut();
        const double q_a = 10.;
        const double q_b = 80.;
        const double Y1 = 0.;
        const double Y2 = 1.;
        const double roots = cstPar->getRootS();
        // Parton luminosity.
        cout << "Start luminosity with 'value':\n";
        clock_t time = clock();
        for (int iQ = 0; iQ <= nQ; ++iQ) {
            const double q = q_a + double(iQ) * (q_b - q_a) / double(nQ);
            const double x1p = (q / roots) * exp(Y1);
            const double x1m = (q / roots) * exp(-Y1);
            const double x2p = (q / roots) * exp(Y2);
            const double x2m = (q / roots) * exp(-Y2);
            const double y_a = 1. / q;
            for (int iY = 0; iY < nY; ++iY) {
                const double y = y_a + double(iY) * (y_b - y_a) / double(nY);
                setYParam(y);
                //update(q);
                double val = 0.;
                val = value(x1p,x2p,q,-1,2,1,-1) * value(x1m,x2m,q,2,-1,1,-1);
                val += value(x1p,x2p,q,2,-1,1,-1) * value(x1m,x2m,q,-1,2,1,-1);
                val += value(x1p,x2p,q,2,2,1,1) * value(x1m,x2m,q,-1,-1,1,1);
                val += value(x1p,x2p,q,-1,-1,1,1) * value(x1m,x2m,q,2,2,1,1);
                cout << q << "\t" << y << "\t" << val << "\n";
            }
        }
        time = clock() - time;
        cout << "End luminosity with 'value': " << static_cast<double>(time) / CLOCKS_PER_SEC << " s.\n";
        // Valence and sea components.
        cout << "Start luminosity with 'valuevs':\n";
        time = clock();
        for (int iQ = 0; iQ <= nQ; ++iQ) {
            const double q = q_a + double(iQ) * (q_b - q_a) / double(nQ);
            const double x1p = (q / roots) * exp(Y1);
            const double x1m = (q / roots) * exp(-Y1);
            const double x2p = (q / roots) * exp(Y2);
            const double x2m = (q / roots) * exp(-Y2);
            const double y_a = 1. / q;
            for (int iY = 0; iY < nY; ++iY) {
                const double y = y_a + double(iY) * (y_b - y_a) / double(nY);
                setYParam(y);
                //update(q);
                double val = 0.;
                val = valuevs(x1p,x2p,q,-1,2,1,-1) * valuevs(x1m,x2m,q,2,-1,1,-1) + valuevs(x1p,x2p,q,-1,8,1,-1) * valuevs(x1m,x2m,q,2,-1,1,-1) + valuevs(x1p,x2p,q,-1,2,1,-1) * valuevs(x1m,x2m,q,8,-1,1,-1) + valuevs(x1p,x2p,q,-1,8,1,-1) * valuevs(x1m,x2m,q,8,-1,1,-1);
                val += valuevs(x1p,x2p,q,2,-1,1,-1) * valuevs(x1m,x2m,q,-1,2,1,-1) + valuevs(x1p,x2p,q,8,-1,1,-1) * valuevs(x1m,x2m,q,-1,2,1,-1) + valuevs(x1p,x2p,q,2,-1,1,-1) * valuevs(x1m,x2m,q,-1,8,1,-1) + valuevs(x1p,x2p,q,8,-1,1,-1) * valuevs(x1m,x2m,q,-1,8,1,-1);
                val += valuevs(x1p,x2p,q,8,8,1,1) * valuevs(x1m,x2m,q,-1,-1,1,1) + valuevs(x1p,x2p,q,2,8,1,1) * valuevs(x1m,x2m,q,-1,-1,1,1) + valuevs(x1p,x2p,q,8,2,1,1) * valuevs(x1m,x2m,q,-1,-1,1,1) + valuevs(x1p,x2p,q,2,2,1,1) * valuevs(x1m,x2m,q,-1,-1,1,1);
                val += valuevs(x1p,x2p,q,-1,-1,1,1) * valuevs(x1m,x2m,q,8,8,1,1) + valuevs(x1p,x2p,q,-1,-1,1,1) * valuevs(x1m,x2m,q,2,8,1,1) + valuevs(x1p,x2p,q,-1,-1,1,1) * valuevs(x1m,x2m,q,8,2,1,1) + valuevs(x1p,x2p,q,-1,-1,1,1) * valuevs(x1m,x2m,q,2,2,1,1);
                cout << q << "\t" << y << "\t" << val << "\n";
            }
        }
        time = clock() - time;
        cout << "End luminosity with 'valuevs': " << static_cast<double>(time) / CLOCKS_PER_SEC << " s.\n";
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
} // end namespace dShower

