from itertools import product

if __name__ == "__main__":	
	
	f = open("combs_WW.txt", "w")
	
	udata=('u',2/3,2)
	ddata=('d',-1/3,1)
	sdata=('s',-1/3,3)
	ubdata=('U',-2/3,-2)
	dbdata=('D',1/3,-1)
	sbdata=('S',1/3,-3)

	data=[udata,ddata,sdata,ubdata,dbdata,sbdata]
	
	numlist=[0,1,2,3,4,5]
	#get all combinations of quark labels
	combs=list(product(numlist,numlist,repeat=2)) 
	
	listpos=[]
	listneg=[]
	
	#find all combinations that satisfy the charge conservation requirements
	for i in combs:
		chsum=data[i[0]][1]+data[i[1]][1]+data[i[2]][1]+data[i[3]][1]
		if (chsum<2.1 and chsum>1.9):
			listpos.append(i)
		if (chsum<-1.9 and chsum>-2.1):
			listneg.append(i)
	
	
	print('-----------------------------------------------------------')
	print('W-W- Symmetries')
	
	#print(numneg,listneg)
	
	final_quarks_neg=[]
	
	symms_neg_1324=[]
	for i in range(len(listneg)):
		elem_1=listneg[i]
		for j in range(len(listneg)):
			elem_2=listneg[j]
			if i==j:
				continue
			elif(elem_1[0]==elem_2[2] and elem_1[1]==elem_2[3] and elem_1[2]==elem_2[0] and elem_1[3]==elem_2[1]):
				#print(elem_1, elem_2,(i,j), '13,24 symmetric')
				if((j,i) in symms_neg_1324):
					continue
				else:
					symms_neg_1324.append((i,j))
	
	finals_neg=[]
	#print(len(symms_neg_1324))
	for j in symms_neg_1324:
		i=j[0]
		#print(listneg[i],data[listneg[i][0]][0],data[listneg[i][1]][0],data[listneg[i][2]][0],data[listneg[i][3]][0])
		finals_neg.append((listneg[i],2))
	
	vals_neg=[]
	#print(len(symms_neg_1324))
	for j in symms_neg_1324:
		i=j[0]
		i2=j[1]
		#print(listneg[i],data[listneg[i][0]][0],data[listneg[i][1]][0],data[listneg[i][2]][0],data[listneg[i][3]][0])
		vals_neg.append(i)
		vals_neg.append(i2)
	
	tots_neg=list(range(0,len(listneg)))
	
	for i in tots_neg:
		if i not in vals_neg:
			finals_neg.append((listneg[i],1))
	#print(finals_neg,len(finals_neg))
	
	for i in finals_neg:
		print(data[i[0][0]][2],data[i[0][1]][2],data[i[0][2]][2],data[i[0][3]][2])
		f.write(str(data[i[0][0]][2])+','+str(data[i[0][1]][2])+','+str(data[i[0][2]][2])+','+str(data[i[0][3]][2]))
		f.write(','+str(i[1])+'\n')
	
	print('-----------------------------------------------------------')
	print('W+W+ Symmetries')
	
	#print(numpos,listpos)
	
	final_quarks_pos=[]
	
	symms_pos_1324=[]
	nonsymm_pos_1324=[]
	for i in range(int(len(listpos))):
		elem_1=listpos[i]
		for j in range(len(listpos)):
			elem_2=listpos[j]
			if i==j:
				continue
			elif(elem_1[0]==elem_2[2] and elem_1[1]==elem_2[3] and elem_1[2]==elem_2[0] and elem_1[3]==elem_2[1]):
				#print(elem_1, elem_2,(i,j), '13,24 symmetric')
				if((j,i) in symms_pos_1324):
					continue
				else:
					symms_pos_1324.append((i,j))
	
	finals_pos=[]
	#print(len(symms_pos_1324))
	for j in symms_pos_1324:
		i=j[0]
		#print(listpos[i],data[listpos[i][0]][0],data[listpos[i][1]][0],data[listpos[i][2]][0],data[listpos[i][3]][0])
		finals_pos.append((listpos[i],2))
				
	vals_pos=[]
	#print(len(symms_pos_1324))
	for j in symms_pos_1324:
		i=j[0]
		i2=j[1]
		#print(listneg[i],data[listneg[i][0]][0],data[listneg[i][1]][0],data[listneg[i][2]][0],data[listneg[i][3]][0])
		vals_pos.append(i)
		vals_pos.append(i2)
	
	tots_pos=list(range(0,len(listpos)))
	
	for i in tots_pos:
		if i not in vals_pos:
			finals_pos.append((listpos[i],1))
	#print(finals_pos,len(finals_pos))

	for i in finals_pos:
			print(data[i[0][0]][2],data[i[0][1]][2],data[i[0][2]][2],data[i[0][3]][2])
			f.write(str(data[i[0][0]][2])+','+str(data[i[0][1]][2])+','+str(data[i[0][2]][2])+','+str(data[i[0][3]][2]))
			f.write(','+str(i[1])+'\n')
	f.close()
