import matplotlib.pyplot as plt
import numpy as np
import os
import sys

def main():
	
	file_1=open("combs_WW.txt",'r')
	#file_2=open("Combined_Lum_W+_uudbdb.txt",'r')
	
	numfiles=int(sys.argv[1])
	
	posvals=np.zeros(numfiles)
	negvals=np.zeros(numfiles)
	tots=np.zeros(numfiles)
	asyms=np.zeros(numfiles)
	ymins=np.zeros(numfiles)
	
	index=0
	for filename in os.listdir('/home/lthsmith/Desktop/dShowerOL/src/Integrals/Temp_Mixpol'):
		
		if len(filename)<30:
			continue
		if(filename[0]!='C'):
			continue
			
		rapmin=float(filename[-12]+filename[-11]+filename[-10]+filename[-9]+filename[-8]+filename[-7]+filename[-6]+filename[-5])
		ymins[index]=rapmin
		f=open(filename,'r')
		data_f=f.readlines()
		for j in range(1,len(data_f)):
			prodval=float(data_f[j].strip().split(',')[0])
			tots[index]+=float(data_f[j].strip().split(',')[1])
			if prodval>=0:
				posvals[index]+=float(data_f[j].strip().split(',')[1])
			else:
				negvals[index]+=float(data_f[j].strip().split(',')[1])
		asyms[index]+=(negvals[index]-posvals[index])/tots[index]
		
		index+=1
	
	
	data=[]
	for i in range(len(ymins)):
		data.append((ymins[i],asyms[i]))

	
	data_sorted = sorted(data, key=lambda tup: tup[0])
	
	file_out=open("Asyms_Mixpol.txt",'w')
	file_out.write("ymin,asym\n")
	
	for i in range(len(data_sorted)):
		file_out.write(str(data_sorted[i][0]))
		file_out.write(",")
		file_out.write(str(data_sorted[i][1]))
		file_out.write("\n")
	
	file_out.close()
	
	plt.title('Asyms for Mixpol')
	plt.scatter(ymins,asyms)
	plt.ylabel("Aysmmetry")
	plt.xlabel('Minimum Cut on Rapidity Product')
	
	plt.show()	
	
main()
