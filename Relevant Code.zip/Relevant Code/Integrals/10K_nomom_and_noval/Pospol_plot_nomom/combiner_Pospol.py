import matplotlib.pyplot as plt
import numpy as np
import os
import sys

def main():
	
	file_1=open("combs_WW.txt",'r')
	#file_2=open("Combined_Lum_W+_uudbdb.txt",'r')
	
	rapmin_in=sys.argv[1]
	
	print(rapmin_in)
	
	rm=str(rapmin_in)+"00000"
	print(rm)
	
	data_1=file_1.readlines()
	
	qnames=[]
	
	for i in range(1,len(data_1)):
		
		line=data_1[i]
		lineelems=line.strip().split(',')
		
		partons=str(lineelems[0])+str(lineelems[1])+str(lineelems[2])+str(lineelems[3])		
		mult=float(lineelems[4])
		
		qnames.append((partons,mult))
		
	#print(qnames,len(qnames))
	
	data=np.zeros(48)
	
	prods=np.zeros(48)
	
	for filename in os.listdir('/home/lthsmith/Desktop/dShowerOL/src/Integrals/Pospol_plot_nomom'):
		if len(filename)<30:
			continue
		quark=filename[15]+filename[16]+filename[17]+filename[18]+filename[19]+filename[20]
		rapmin=str(filename[-12]+filename[-11]+filename[-10]+filename[-9]+filename[-8]+filename[-7]+filename[-6]+filename[-5])
		if rapmin!=rm:
			continue
		#print(quark)
		#print(rapmin)
		for i in range(len(qnames)):
			#print(quark)
			if quark==qnames[i][0]:
				mult=qnames[i][1]
				#print(quark,mult)
				f=open(filename,'r')
				data_f=f.readlines()
				for j in range(1,len(data_f)):
					prodvals=data_f[j].strip().split(',')[0]
					prods[j-1]=float(prodvals)
					print(prodvals,filename)
					
					sumelem=float(data_f[j].strip().split(',')[1])
					data[j-1]+=mult*sumelem
	print(data)
	print(prods,len(prods))

	
	filenew = open("Combined_Lum_Pospol_"+str(rm)+".txt", "w")
	filenew.write("rapprod_centre,Lum,err\n")
	
	for i in range(len(data)):
		filenew.write(str(prods[i])+",")
		
		val_lum=data[i]
		filenew.write(str(val_lum)+"\n")
	filenew.close()
	'''
	plt.title('Combined Luminosity for MSTW')
	plt.step(prods,data,'k',where='mid',linewidth=1)
	plt.ylabel("MC Magnitude")
	plt.xlabel('Rapidity Product')
	
	plt.show()
	
	'''	

main()
