import matplotlib.pyplot as plt
import numpy as np
import os

def main():
	
	prods=[]
	data_PDGS=[]
	data_MIXPOL=[]
	data_POSPOL=[]
	data_MSTW=[]
	
	#print(os.getcwd())
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals/PDGS_1K_POSPOL")
	#print(os.getcwd())
	file_PDGS=open('Combined_Lum_PDGS.txt','r')
	content_PDGS=file_PDGS.readlines()
	
	for i in range(1,len(content_PDGS)):
		
		prodval=content_PDGS[i].strip().split(',')[0]
		
		prodval=float(prodval)
		#print(prodval)
		#print(prodval)
		prods.append(prodval)
		
		val_PDGS=content_PDGS[i].strip().split(',')[1]
		#print(val_PDGS)
		
		data_PDGS.append(float(val_PDGS))
	file_PDGS.close()
	#print(prods)
	#print(data_PDGS)
	
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals")
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals/MIXPOL_1K")
	file_MIXPOL=open('Combined_Lum_MIXPOL.txt','r')
	content_MIXPOL=file_MIXPOL.readlines()
	
	for i in range(1,len(content_MIXPOL)):

		val_MIXPOL=content_MIXPOL[i].strip().split(',')[1]
		
		
		data_MIXPOL.append(float(val_MIXPOL))
	#print(data_MIXPOL)
	file_MIXPOL.close()
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals")
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals/POSPOL_1K")
	
	file_POSPOL=open('Combined_Lum_POSPOL.txt','r')
	content_POSPOL=file_POSPOL.readlines()
	
	for i in range(1,len(content_POSPOL)):

		val_POSPOL=content_POSPOL[i].strip().split(',')[1]
		
		
		data_POSPOL.append(float(val_POSPOL))
	#print(data_POSPOL)
	file_POSPOL.close()
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals")
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals/MSTW_1000K")
	
	file_MSTW=open('Combined_Lum_MSTW.txt','r')
	content_MSTW=file_MSTW.readlines()
	
	for i in range(1,len(content_MSTW)):

		val_MSTW=content_MSTW[i].strip().split(',')[1]
		
		
		data_MSTW.append(float(val_MSTW))
	#print(data_MSTW)
	
	file_MSTW.close()
	os.chdir("/home/lthsmith/Desktop/dShowerOL/src/Integrals")
	#print(prods)
	#print(data_PDGS)
	##print(data_MIXPOL)
	##print(data_POSPOL)
	##print(data_MSTW)
	
	posvals=[0,0,0,0]
	negvals=[0,0,0,0]
	tots=[0,0,0,0]
	asym=[]
	
	for i in range(len(prods)):
		tots[0]+=data_PDGS[i]
		tots[1]+=data_MIXPOL[i]
		tots[2]+=data_POSPOL[i]
		tots[3]+=data_MSTW[i]
		
		if prods[i]>0:
			posvals[0]+=data_PDGS[i]
			posvals[1]+=data_MIXPOL[i]
			posvals[2]+=data_POSPOL[i]
			posvals[3]+=data_MSTW[i]
		else:
			negvals[0]+=data_PDGS[i]
			negvals[1]+=data_MIXPOL[i]
			negvals[2]+=data_POSPOL[i]
			negvals[3]+=data_MSTW[i]
	#print(posvals,negvals,tots)
	
	for i in range(len(tots)):
		asym.append((posvals[i]-negvals[i])/tots[i])
		
	print('PDGS: '+str(asym[0]))#
	print('MIXPOL: '+str(asym[1]))
	print('POSPOL: '+str(asym[2]))
	print('MSTW: '+str(asym[3]))
	
main()
